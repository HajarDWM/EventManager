import { Component, OnInit, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { MenuItemService, MenuItem } from '../../../../core/services/menu-item.service';
import { EventService } from '../../services/event.service';
import { GuestService, Guest } from '../../../../core/services/guest.service';
import { CatererService } from '../../../../core/services/caterer.service';
import { CurrencyService } from '../../../../core/services/currency.service';
import { Event } from '../../models/event.model';
import { TranslatePipe } from '../../../../core/pipes/translate.pipe';
import { TranslationService } from '../../../../core/services/translation.service';

@Component({
  selector: 'app-menu-list',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink, TranslatePipe],
  templateUrl: './menu-list.html'
})
export class MenuList implements OnInit {
  private readonly route = inject(ActivatedRoute);
  private readonly menuItemService = inject(MenuItemService);
  private readonly eventService = inject(EventService);
  private readonly guestService = inject(GuestService);
  private readonly catererService = inject(CatererService);
  protected readonly currencyService = inject(CurrencyService);
  protected readonly translateService = inject(TranslationService);

  protected readonly currencySymbol = computed(() => this.currencyService.activeSymbol());

  protected convert(amountInEUR: number | undefined | null): number {
    return this.currencyService.convertFromEUR(amountInEUR);
  }

  protected readonly eventId = signal<number | null>(null);
  protected readonly event = signal<Event | null>(null);
  protected readonly guests = signal<Guest[]>([]);
  protected readonly menuItems = signal<MenuItem[]>([]);
  protected readonly mealType = signal<string>('PLATS_FIXES');
  protected readonly masterCateringMode = signal<'BUFFET' | 'PLATS_FIXES' | 'MIX'>('PLATS_FIXES');

  protected readonly confirmedGuestsCount = computed(() => 
    this.guests().filter(g => g.status === 'CONFIRMED').length
  );

  protected readonly isLoading = signal<boolean>(true);
  protected readonly isSaving = signal<boolean>(false);
  protected readonly successMessage = signal<string>('');
  protected readonly errorMessage = signal<string>('');

  protected readonly isSubscriptionExpired = computed(() => {
    const profile = this.catererService.currentProfile();
    if (profile && profile.role === 'SUPER_ADMIN') return false;
    return profile && (!!profile.isExpired || !!profile.expired || profile.subscriptionStatus === 'EXPIRED');
  });

  // Category Filter
  protected readonly selectedCategory = signal<string>('ALL');

  // Modal State
  protected readonly isModalOpen = signal<boolean>(false);
  protected readonly isEditing = signal<boolean>(false);
  protected readonly editingItemId = signal<number | null>(null);

  // Form Fields
  protected readonly name = signal<string>('');
  protected readonly category = signal<string>('STARTER');
  protected readonly pricePerPerson = signal<number>(0);
  protected readonly dietaryTag = signal<string>('');
  protected readonly description = signal<string>('');
  protected readonly imageUrl = signal<string>('');

  // Image Upload
  protected readonly isUploadingImage = signal<boolean>(false);
  protected readonly imageUploadError = signal<string>('');
  protected readonly imagePreviewUrl = signal<string>('');
  protected readonly selectedDiets = signal<Record<string, boolean>>({});
  protected readonly customDietNotes = signal<string>('');
  protected readonly mixSectionChoice = signal<'BUFFET' | 'ASSIS'>('BUFFET');
  
  protected readonly isAutocompleteOpen = signal<boolean>(false);

  protected readonly commonDietaryOptions = [
    { label: 'Végétarien', value: 'Végétarien', isCritical: false },
    { label: 'Vegan', value: 'Vegan', isCritical: false },
    { label: 'Sans Gluten', value: 'Sans Gluten', isCritical: false },
    { label: 'Sans Lactose', value: 'Sans Lactose', isCritical: false },
    { label: 'Sans Arachides (Alerte Médicale)', value: 'Sans Arachides', isCritical: true },
    { label: 'Halal', value: 'Halal', isCritical: false },
    { label: 'Sans Fruits de mer', value: 'Sans Fruits de mer', isCritical: false },
    { label: 'Sans Sucre', value: 'Sans Sucre', isCritical: false }
  ];

  protected readonly staticSuggestionsDetail: Record<string, { category: string, price: number, dietary: string }> = {
    "Foie gras de canard maison": { category: 'STARTER', price: 15, dietary: 'Sans Gluten' },
    "Saumon fumé et blinis": { category: 'STARTER', price: 12, dietary: 'Sans Arachides' },
    "Salade landaise": { category: 'STARTER', price: 10, dietary: 'Sans Porc' },
    "Velouté de cèpes": { category: 'STARTER', price: 8, dietary: 'Végétarien' },
    "Tartare de saumon avocat": { category: 'STARTER', price: 11, dietary: 'Sans Gluten' },
    "Filet de bœuf sauce morilles": { category: 'MAIN', price: 28, dietary: '' },
    "Magret de canard au miel": { category: 'MAIN', price: 24, dietary: 'Sans Porc' },
    "Dos de cabillaud sauce vierge": { category: 'MAIN', price: 22, dietary: 'Sans Arachides' },
    "Risotto aux truffes": { category: 'MAIN', price: 20, dietary: 'Végétarien, Sans Gluten' },
    "Suprême de volaille": { category: 'MAIN', price: 18, dietary: '' },
    "Tarte Tatin et crème fraîche": { category: 'DESSERT', price: 7, dietary: 'Végétarien' },
    "Moelleux au chocolat": { category: 'DESSERT', price: 6.5, dietary: 'Végétarien' },
    "Crème brûlée vanille Bourbon": { category: 'DESSERT', price: 6, dietary: 'Végétarien, Sans Gluten' },
    "Mille-feuille": { category: 'DESSERT', price: 7.5, dietary: 'Végétarien' },
    "Café gourmand": { category: 'DESSERT', price: 8, dietary: 'Végétarien' },
    "Champagne Brut": { category: 'BEVERAGE', price: 9, dietary: 'Vegan, Sans Gluten' },
    "Vin rouge AOC": { category: 'BEVERAGE', price: 6, dietary: 'Vegan, Sans Gluten' },
    "Vin blanc Chardonnay": { category: 'BEVERAGE', price: 6.5, dietary: 'Vegan, Sans Gluten' },
    "Eau minérale": { category: 'BEVERAGE', price: 3, dietary: 'Vegan, Sans Gluten' },
    "Softs et jus de fruits": { category: 'BEVERAGE', price: 4, dietary: 'Vegan, Sans Gluten' },
    "Buffet de fromages affinés": { category: 'OTHER', price: 12, dietary: 'Végétarien, Sans Gluten' },
    "Assortiment de pièces cocktail": { category: 'OTHER', price: 25, dietary: '' },
    "Buffet de desserts": { category: 'OTHER', price: 15, dietary: 'Végétarien' },
    "Atelier découpe de jambon serrano": { category: 'OTHER', price: 18, dietary: 'Sans Gluten, Sans Lactose' }
  };

  protected readonly globalMenuItems = signal<MenuItem[]>([]);

  protected readonly mergedSuggestionsDetail = computed(() => {
    const map: Record<string, { price: number, dietary: string, description?: string, imageUrl?: string }> = {};
    
    // First populate with static template suggestions (convert EUR to active currency)
    Object.entries(this.staticSuggestionsDetail).forEach(([name, details]) => {
      map[name] = {
        price: this.convert(details.price),
        dietary: details.dietary,
        description: undefined,
        imageUrl: undefined
      };
    });

    // Merge in dynamically saved menu items from database
    this.globalMenuItems().forEach(item => {
      const existing = map[item.name];
      if (!existing || (item.imageUrl && !existing.imageUrl)) {
        map[item.name] = {
          price: item.pricePerPerson,
          dietary: item.dietaryTag || '',
          description: item.description,
          imageUrl: item.imageUrl
        };
      }
    });

    return map;
  });

  protected readonly mergedSuggestions = computed(() => {
    return Object.keys(this.mergedSuggestionsDetail());
  });

  protected readonly filteredSuggestions = computed(() => {
    const term = this.name().toLowerCase().trim();
    const suggestions = this.mergedSuggestions();
    if (!term) {
      return suggestions;
    }
    return suggestions.filter(s => s.toLowerCase().includes(term));
  });

  protected readonly dishSuggestions = computed(() => {
    const existingNames = this.menuItems().map(item => item.name);
    const combined = [...new Set([...existingNames, ...this.mergedSuggestions()])];
    return combined.sort();
  });

  // Computed Metrics
  protected readonly filteredMenuItems = computed(() => {
    const items = this.menuItems();
    const cat = this.selectedCategory();
    if (cat === 'ALL') return items;
    return items.filter(item => item.category === cat);
  });



  protected readonly totalCateringBudget = computed(() => {
    const items = this.menuItems();
    const confirmed = this.confirmedGuestsCount();
    if (items.length === 0) return 0;

    const mode = this.masterCateringMode();
    const guestMultiplier = confirmed > 0 ? confirmed : (this.event()?.guestCount || 1);

    if (mode === 'MIX') {
      // 1. Buffet items: consumed by ALL confirmed guests
      const buffetItems = items.filter(i => i.category !== 'MAIN' && i.category !== 'BUFFET_MAIN');
      const buffetPerPersonCost = buffetItems.reduce((sum, item) => sum + (item.pricePerPerson || 0), 0);
      const totalBuffetCost = buffetPerPersonCost * guestMultiplier;

      // 2. Main course (Plat à table): Each guest chooses only 1 main dish
      const mainItems = items.filter(i => i.category === 'MAIN' || i.category === 'BUFFET_MAIN');
      let totalMainCost = 0;
      
      if (mainItems.length > 0) {
        const totalSelections = mainItems.reduce((sum, i) => sum + (i.selectedCount || 0), 0);
        const actualSelectionsCost = mainItems.reduce((sum, i) => sum + ((i.pricePerPerson || 0) * (i.selectedCount || 0)), 0);
        
        const avgMainPrice = mainItems.reduce((sum, i) => sum + (i.pricePerPerson || 0), 0) / mainItems.length;
        const unselectedGuests = Math.max(0, guestMultiplier - totalSelections);
        
        totalMainCost = actualSelectionsCost + (unselectedGuests * avgMainPrice);
      }

      return totalBuffetCost + totalMainCost;
    } else if (mode === 'BUFFET') {
      const buffetPerPerson = items.reduce((sum, item) => sum + (item.pricePerPerson || 0), 0);
      return buffetPerPerson * guestMultiplier;
    } else {
      // PLATS_FIXES: 1 starter + 1 main + 1 dessert + 1 beverage per guest
      const starters = items.filter(i => i.category === 'STARTER' || i.category === 'BUFFET_STARTER');
      const mains = items.filter(i => i.category === 'MAIN' || i.category === 'BUFFET_MAIN');
      const desserts = items.filter(i => i.category === 'DESSERT' || i.category === 'BUFFET_DESSERT');
      const beverages = items.filter(i => i.category === 'BEVERAGE' || i.category === 'BUFFET_BEVERAGES');

      const avgStarter = starters.length > 0 ? starters.reduce((s, i) => s + (i.pricePerPerson || 0), 0) / starters.length : 0;
      const avgMain = mains.length > 0 ? mains.reduce((s, i) => s + (i.pricePerPerson || 0), 0) / mains.length : 0;
      const avgDessert = desserts.length > 0 ? desserts.reduce((s, i) => s + (i.pricePerPerson || 0), 0) / desserts.length : 0;
      const avgBeverage = beverages.length > 0 ? beverages.reduce((s, i) => s + (i.pricePerPerson || 0), 0) / beverages.length : 0;

      const singleGuestCost = avgStarter + avgMain + avgDessert + avgBeverage;
      return singleGuestCost * guestMultiplier;
    }
  });

  protected readonly averageCostPerPerson = computed(() => {
    const confirmed = this.confirmedGuestsCount();
    const totalBudget = this.totalCateringBudget();
    const guestMultiplier = confirmed > 0 ? confirmed : (this.event()?.guestCount || 1);
    if (guestMultiplier > 0) {
      return totalBudget / guestMultiplier;
    }
    return totalBudget;
  });

  protected readonly starterCount = computed(() => {
    return this.menuItems().filter(i => i.category === 'STARTER').length;
  });

  protected readonly mainCount = computed(() => {
    return this.menuItems().filter(i => i.category === 'MAIN').length;
  });

  protected readonly dessertCount = computed(() => {
    return this.menuItems().filter(i => i.category === 'DESSERT').length;
  });

  protected readonly beverageCount = computed(() => {
    return this.menuItems().filter(i => i.category === 'BEVERAGE').length;
  });

  protected readonly otherCount = computed(() => {
    return this.menuItems().filter(i => i.category === 'OTHER').length;
  });

  protected readonly hasBuffetEntrees = computed(() => this.isFormatSelected('BUFFET_ENTREES'));
  protected readonly hasBuffetDesserts = computed(() => this.isFormatSelected('BUFFET_DESSERTS'));
  protected readonly hasBuffetBeverages = computed(() => this.isFormatSelected('BUFFET_BEVERAGES'));

  protected getMixPart1Title(): string {
    const parts = [];
    if (this.hasBuffetEntrees()) parts.push(this.translateService.translate('CATERING.COCKTAIL_ENTREES'));
    if (this.hasBuffetDesserts()) parts.push(this.translateService.translate('CATERING.DESSERTS'));
    if (this.hasBuffetBeverages()) parts.push(this.translateService.translate('CATERING.BEVERAGES'));

    if (parts.length === 0) return this.translateService.translate('CATERING.MIX_PART1_DEFAULT');
    
    let joined = parts[0];
    if (parts.length > 1) {
      const last = parts.pop();
      joined = parts.join(', ') + ' & ' + last;
    }
    
    return `${this.translateService.translate('CATERING.MIX_PART1_TITLE')} (${joined})`;
  }

  protected getMixPart2Title(): string {
    const parts = [];
    if (this.isFormatSelected('PLATS_FIXES')) parts.push(this.translateService.translate('CATERING.MAIN_COURSE'));
    if (!this.hasBuffetDesserts()) parts.push(this.translateService.translate('CATERING.DESSERTS'));

    if (parts.length === 0) return this.translateService.translate('CATERING.MIX_PART2_DEFAULT');
    
    let joined = parts[0];
    if (parts.length > 1) {
      const last = parts.pop();
      joined = parts.join(', ') + ' & ' + last;
    }
    
    return `${this.translateService.translate('CATERING.MIX_PART2_TITLE')} (${joined})`;
  }

  public ngOnInit(): void {
    const idParam = this.route.snapshot.paramMap.get('id');
    if (idParam) {
      const id = parseInt(idParam, 10);
      this.eventId.set(id);
      this.loadEventData(id);
      this.loadMenuItems(id);
      this.loadCatererMenuItems();
      this.loadGuests(id);
    }
  }

  private loadGuests(id: number): void {
    this.guestService.getGuestsByEvent(id).subscribe({
      next: (data) => this.guests.set(data),
      error: (err) => console.error('Erreur chargement invités', err)
    });
  }

  private loadCatererMenuItems(): void {
    this.menuItemService.getCatererMenuItems().subscribe({
      next: (items) => {
        this.globalMenuItems.set(items);
      },
      error: (err) => console.error('Erreur chargement catalogue global', err)
    });
  }

  private loadEventData(id: number): void {
    this.eventService.getEventById(id).subscribe({
      next: (data) => {
        this.event.set(data);
        if (data.mealType) {
          this.mealType.set(data.mealType);
          const t = data.mealType;
          if (t.includes('BUFFET_ENTREES') && t.includes('PLATS_FIXES')) {
            this.masterCateringMode.set('MIX');
          } else if (t.startsWith('BUFFET') || t.includes('BUFFET_STANDARD')) {
            this.masterCateringMode.set('BUFFET');
          } else if (t === 'BUFFET') {
            this.masterCateringMode.set('BUFFET');
          } else {
            this.masterCateringMode.set('PLATS_FIXES');
          }
        }
      },
      error: (err) => console.error('Erreur chargement événement', err)
    });
  }

  protected selectMasterMode(mode: 'BUFFET' | 'PLATS_FIXES' | 'MIX'): void {
    this.masterCateringMode.set(mode);
    this.selectedCategory.set('ALL');
    let defaultType = '';
    if (mode === 'BUFFET') {
      defaultType = 'BUFFET_STANDARD,BUFFET_VEG,BUFFET_HALAL,BUFFET_SUCRE_FREE,BUFFET_BEVERAGES';
    } else if (mode === 'PLATS_FIXES') {
      defaultType = 'PLATS_FIXES,COURSE_ENTREE,COURSE_MAIN,COURSE_DESSERT,COURSE_BEVERAGE';
    } else if (mode === 'MIX') {
      defaultType = 'BUFFET_ENTREES,PLATS_FIXES,BUFFET_DESSERTS,BUFFET_BEVERAGES';
    }
    this.saveMealType(defaultType);
  }

  protected readonly availableFormats = [
    { label: 'Entrées sous forme de Buffet', value: 'BUFFET_ENTREES', icon: 'fa-cheese' },
    { label: 'Plat principal servi à table', value: 'PLATS_FIXES', icon: 'fa-concierge-bell' },
    { label: 'Buffet de Desserts', value: 'BUFFET_DESSERTS', icon: 'fa-birthday-cake' },
    { label: 'Buffet Végétarien & Halal', value: 'BUFFET_REGIMES', icon: 'fa-seedling' }
  ];

  protected isFormatSelected(value: string): boolean {
    const current = this.mealType() || '';
    const list = current.split(',').map(s => s.trim());
    if (value === 'COURSE_STARTER' || value === 'COURSE_ENTREE') {
      return list.includes('COURSE_STARTER') || list.includes('COURSE_ENTREE');
    }
    return list.includes(value);
  }

  protected toggleFormat(value: string): void {
    const currentList = (this.mealType() || '').split(',').map(s => s.trim()).filter(Boolean);
    if (value === 'COURSE_STARTER' || value === 'COURSE_ENTREE') {
      const hasStarter = currentList.includes('COURSE_STARTER') || currentList.includes('COURSE_ENTREE');
      if (hasStarter) {
        const filtered = currentList.filter(s => s !== 'COURSE_STARTER' && s !== 'COURSE_ENTREE');
        this.saveMealType(filtered.join(','));
        return;
      } else {
        currentList.push('COURSE_STARTER');
      }
    } else {
      const index = currentList.indexOf(value);
      if (index > -1) {
        currentList.splice(index, 1);
      } else {
        currentList.push(value);
      }
    }
    const newMealType = currentList.join(',');
    this.saveMealType(newMealType);
  }

  protected saveMealType(newType: string): void {
    const currentEvent = this.event();
    if (!currentEvent || !this.eventId()) return;

    this.mealType.set(newType);
    this.eventService.updateEvent(this.eventId()!, {
      ...currentEvent,
      mealType: newType
    }).subscribe({
      next: (updated) => {
        this.event.set(updated);
        this.successMessage.set('Formats de restauration mis à jour avec succès !');
        setTimeout(() => this.successMessage.set(''), 4000);
      },
      error: (err) => {
        this.errorMessage.set('Erreur lors de la mise à jour des formats de restauration.');
        console.error(err);
        setTimeout(() => this.errorMessage.set(''), 4000);
      }
    });
  }

  protected loadMenuItems(id: number): void {
    this.isLoading.set(true);
    this.menuItemService.getMenuItemsByEvent(id).subscribe({
      next: (items) => {
        this.menuItems.set(items);
        this.isLoading.set(false);
      },
      error: (err) => {
        this.isLoading.set(false);
        this.errorMessage.set('Impossible de charger le menu de cet événement.');
        console.error(err);
      }
    });
  }

  protected openAddModal(section?: 'BUFFET' | 'ASSIS'): void {
    this.isEditing.set(false);
    this.editingItemId.set(null);
    this.name.set('');

    const activeCat = this.selectedCategory();
    const currentCat = this.category();

    if (this.masterCateringMode() === 'MIX') {
      const sec = section || this.mixSectionChoice();
      this.mixSectionChoice.set(sec);
      
      // Determine if current category is compatible with target section
      const allowed: string[] = [];
      if (sec === 'BUFFET') {
        if (this.hasBuffetEntrees()) {
          allowed.push('BEVERAGE', 'BUFFET_STARTER', 'STARTER');
        }
        if (this.hasBuffetDesserts()) {
          allowed.push('BUFFET_DESSERT');
        }
      } else {
        allowed.push('MAIN');
        if (!this.hasBuffetDesserts()) allowed.push('DESSERT');
      }
      
      if (!allowed.includes(currentCat)) {
        // Fallback to activeCategory if compatible, otherwise default
        if (allowed.includes(activeCat)) {
          this.category.set(activeCat);
        } else if (allowed.length > 0) {
          this.category.set(allowed[0]);
        } else {
          this.category.set(sec === 'BUFFET' ? 'BUFFET_STARTER' : 'MAIN');
        }
      }
    } else if (this.masterCateringMode() === 'BUFFET') {
      const allowed = ['BUFFET_STARTER', 'BUFFET_MAIN', 'BUFFET_DESSERT', 'BEVERAGE'];
      if (!allowed.includes(currentCat)) {
        if (allowed.includes(activeCat)) {
          this.category.set(activeCat);
        } else {
          this.category.set('BUFFET_STARTER');
        }
      }
    } else {
      const allowed = ['STARTER', 'MAIN', 'DESSERT', 'BEVERAGE', 'OTHER'];
      if (!allowed.includes(currentCat)) {
        if (allowed.includes(activeCat)) {
          this.category.set(activeCat);
        } else {
          this.category.set('STARTER');
        }
      }
    }

    this.pricePerPerson.set(0);
    this.dietaryTag.set('');
    this.selectedDiets.set({});
    this.customDietNotes.set('');
    this.description.set('');
    this.imageUrl.set('');
    this.imagePreviewUrl.set('');
    this.imageUploadError.set('');
    this.isModalOpen.set(true);
  }

  protected openEditModal(item: MenuItem): void {
    this.isEditing.set(true);
    this.editingItemId.set(item.id || null);
    this.name.set(item.name || '');

    const cat = item.category || (this.masterCateringMode() === 'BUFFET' ? 'BUFFET_STARTER' : 'STARTER');
    this.category.set(cat);

    if (this.masterCateringMode() === 'MIX') {
      const isBuffet = ['BUFFET_STARTER', 'STARTER', 'OTHER', 'BEVERAGE', 'BUFFET_DESSERT'].includes(cat);
      this.mixSectionChoice.set(isBuffet ? 'BUFFET' : 'ASSIS');
    }

    this.pricePerPerson.set(item.pricePerPerson || 0);
    this.dietaryTag.set(item.dietaryTag || '');

    // Parse dietaryTag
    const dietsMap: Record<string, boolean> = {};
    const tags = (item.dietaryTag || '').split(',').map(t => t.trim()).filter(Boolean);
    const standardValues = this.commonDietaryOptions.map(o => o.value);
    const customNotesList: string[] = [];

    for (const tag of tags) {
      if (standardValues.includes(tag)) {
        dietsMap[tag] = true;
      } else {
        customNotesList.push(tag);
      }
    }

    this.selectedDiets.set(dietsMap);
    this.customDietNotes.set(customNotesList.join(', '));
    this.description.set(item.description || '');
    this.imageUrl.set(item.imageUrl || '');
    this.imagePreviewUrl.set(item.imageUrl || '');
    this.imageUploadError.set('');
    this.isModalOpen.set(true);
  }

  protected closeModal(): void {
    this.isModalOpen.set(false);
    this.imagePreviewUrl.set('');
    this.imageUploadError.set('');
  }

  protected onImageFileSelected(event: any): void {
    const input = event.target as HTMLInputElement;
    if (!input.files || input.files.length === 0) return;

    const file = input.files[0];
    const allowedTypes = ['image/jpeg', 'image/png', 'image/webp'];
    const maxSizeBytes = 2 * 1024 * 1024; // 2MB

    this.imageUploadError.set('');

    if (!allowedTypes.includes(file.type)) {
      this.imageUploadError.set('Format non autorisé. Utilisez JPG, PNG ou WebP.');
      return;
    }
    if (file.size > maxSizeBytes) {
      this.imageUploadError.set('Image trop volumineuse. Maximum : 2 MB.');
      return;
    }

    // Local preview while uploading
    const reader = new FileReader();
    reader.onload = (e) => {
      this.imagePreviewUrl.set(e.target?.result as string);
    };
    reader.readAsDataURL(file);

    // Upload to backend
    this.isUploadingImage.set(true);
    this.menuItemService.uploadMenuImage(file).subscribe({
      next: (res) => {
        this.imageUrl.set('http://localhost:8080' + res.url);
        this.isUploadingImage.set(false);
      },
      error: (err) => {
        this.imageUploadError.set(err.error?.error || 'Erreur lors de l\'upload.');
        this.isUploadingImage.set(false);
      }
    });
  }

  protected toggleDiet(value: string, checked: boolean): void {
    this.selectedDiets.update(map => ({
      ...map,
      [value]: checked
    }));
  }

  protected onAutocompleteFocusOut(): void {
    setTimeout(() => {
      this.isAutocompleteOpen.set(false);
    }, 200);
  }

  protected selectSuggestion(suggestion: string): void {
    this.name.set(suggestion);
    this.isAutocompleteOpen.set(false);

    // Auto-select price, dietary, and description from merged details
    const detail = this.mergedSuggestionsDetail()[suggestion];
    if (detail) {
      this.pricePerPerson.set(detail.price);
      if (detail.description) {
        this.description.set(detail.description);
      }
      this.imageUrl.set(detail.imageUrl || '');

      // Parse and check the dietary checkboxes
      const dietsMap: Record<string, boolean> = {};
      const tags = detail.dietary.split(',').map(t => t.trim()).filter(Boolean);
      const standardValues = this.commonDietaryOptions.map(o => o.value);
      const customNotesList: string[] = [];

      for (const tag of tags) {
        if (standardValues.includes(tag)) {
          dietsMap[tag] = true;
        } else {
          customNotesList.push(tag);
        }
      }

      this.selectedDiets.set(dietsMap);
      this.customDietNotes.set(customNotesList.join(', '));
    }
  }

  protected onNameChange(newName: string): void {
    this.name.set(newName);

    // Check if the input matches any known suggestion
    const detail = this.mergedSuggestionsDetail()[newName];
    if (detail) {
      this.pricePerPerson.set(detail.price);
      if (detail.description) {
        this.description.set(detail.description);
      }
      this.imageUrl.set(detail.imageUrl || '');

      // Parse and check the dietary checkboxes
      const dietsMap: Record<string, boolean> = {};
      const tags = detail.dietary.split(',').map(t => t.trim()).filter(Boolean);
      const standardValues = this.commonDietaryOptions.map(o => o.value);
      const customNotesList: string[] = [];

      for (const tag of tags) {
        if (standardValues.includes(tag)) {
          dietsMap[tag] = true;
        } else {
          customNotesList.push(tag);
        }
      }

      this.selectedDiets.set(dietsMap);
      this.customDietNotes.set(customNotesList.join(', '));
    }
  }

  protected onSaveMenuItem(): void {
    if (!this.name().trim()) {
      this.errorMessage.set('Le nom du plat est obligatoire.');
      return;
    }

    const currentEventId = this.eventId();
    if (!currentEventId) return;

    this.isSaving.set(true);
    this.successMessage.set('');
    this.errorMessage.set('');

    // Reconstruct dietaryTag from checkboxes and custom notes
    const activeDiets = Object.entries(this.selectedDiets())
      .filter(([_, checked]) => checked)
      .map(([value]) => value);

    if (this.customDietNotes().trim()) {
      activeDiets.push(this.customDietNotes().trim());
    }

    const assembledDietaryTag = activeDiets.join(', ');

    const payload: MenuItem = {
      name: this.name().trim(),
      category: this.category(),
      pricePerPerson: this.pricePerPerson() || 0,
      dietaryTag: assembledDietaryTag,
      description: this.description().trim(),
      imageUrl: this.imageUrl().trim() || undefined
    };

    if (this.isEditing() && this.editingItemId()) {
      this.menuItemService.updateMenuItem(this.editingItemId()!, payload).subscribe({
        next: (updated) => {
          this.isSaving.set(false);
          this.menuItems.update(list => list.map(i => i.id === updated.id ? updated : i));
          this.loadCatererMenuItems();
          this.successMessage.set('Plat modifié avec succès !');
          this.closeModal();
        },
        error: (err) => {
          this.isSaving.set(false);
          this.errorMessage.set('Erreur lors de la modification du plat.');
          console.error(err);
        }
      });
    } else {
      this.menuItemService.createMenuItem(currentEventId, payload).subscribe({
        next: (created) => {
          this.isSaving.set(false);
          this.menuItems.update(list => [...list, created]);
          this.loadCatererMenuItems();
          this.successMessage.set('Plat ajouté au menu !');
          this.closeModal();
        },
        error: (err) => {
          this.isSaving.set(false);
          this.errorMessage.set('Erreur lors de la création du plat.');
          console.error(err);
        }
      });
    }
  }

  protected onMixSectionChange(sec: 'BUFFET' | 'ASSIS'): void {
    this.mixSectionChoice.set(sec);
    this.category.set(sec === 'BUFFET' ? 'BUFFET_STARTER' : 'MAIN');
  }

  protected onDeleteMenuItem(item: MenuItem): void {
    if (confirm(`Voulez-vous vraiment supprimer "${item.name}" du menu ?`)) {
      if (!item.id) return;
      this.menuItemService.deleteMenuItem(item.id).subscribe({
        next: () => {
          this.menuItems.update(list => list.filter(i => i.id !== item.id));
          this.successMessage.set('Plat supprimé du menu.');
        },
        error: (err) => {
          this.errorMessage.set('Erreur lors de la suppression du plat.');
          console.error(err);
        }
      });
    }
  }

  protected getCategoryBadgeClass(cat: string): string {
    return 'bg-body-dark text-dark';
  }

  protected getCategoryLabel(cat: string): string {
    if (this.masterCateringMode() === 'MIX') {
      switch (cat) {
        case 'BEVERAGE': return "Boissons d'accueil";
        case 'BUFFET_STARTER': return 'Pièces cocktail';
        case 'STARTER': return 'Salad Bar';
        case 'MAIN': return 'Plats';
        case 'DESSERT': return 'Desserts';
        case 'BUFFET_DESSERT': return 'Station Desserts (Buffet)';
        default: return cat;
      }
    }
    switch (cat) {
      case 'STARTER': return 'Entrées';
      case 'MAIN': return 'Plats';
      case 'DESSERT': return 'Desserts';
      case 'BEVERAGE': return 'Boissons';
      case 'OTHER': return 'Autres';
      case 'BUFFET_STARTER': return 'Pièces cocktail';
      case 'BUFFET_MAIN': return 'Plats Chauds';
      case 'BUFFET_DESSERT': return 'Station Desserts';
      default: return cat;
    }
  }
}
