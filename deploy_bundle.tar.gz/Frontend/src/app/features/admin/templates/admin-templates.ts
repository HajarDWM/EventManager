import { Component, OnInit, signal, computed, inject, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TemplateService, DigitalTemplate } from '../../../core/services/template.service';
import { loadGoogleFont } from '../../../core/utils/font-loader';
import { 
  TEMPLATE_TAXONOMY, 
  MainCategoryInfo, 
  SubCategoryInfo, 
  getCategoryTaxonomy, 
  getAllSubcategoriesForCategory 
} from '../../../core/constants/template-taxonomy.constants';

@Component({
  selector: 'app-admin-templates',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './admin-templates.html',
  styleUrls: ['./admin-templates.scss']
})
export class AdminTemplates implements OnInit {
  private readonly templateService = inject(TemplateService);
  private readonly cdr = inject(ChangeDetectorRef);

  protected readonly templates = signal<DigitalTemplate[]>(this.templateService.templates());
  protected readonly isLoading = signal(!this.templateService.isLoaded() && this.templateService.templates().length === 0);
  protected readonly successMessage = signal('');
  protected readonly errorMessage = signal('');

  // Dynamic Taxonomy Reference from TemplateService
  protected readonly taxonomy = computed(() => this.templateService.categories());

  // Category & SubCategory Filters
  protected readonly activeCategoryFilter = signal<string>('ALL');
  protected readonly activeSubCategoryFilter = signal<string>('ALL');

  protected readonly currentMainCategoryInfo = computed(() => getCategoryTaxonomy(this.activeCategoryFilter(), this.taxonomy()));
  protected readonly availableSubCategoriesForFilter = computed(() => this.currentMainCategoryInfo()?.subCategories || []);

  protected readonly filteredTemplates = computed(() => {
    const catFilter = this.activeCategoryFilter();
    const subFilter = this.activeSubCategoryFilter();
    const allTaxonomy = this.taxonomy();
    let list = this.templates();

    if (catFilter !== 'ALL') {
      const mainCat = getCategoryTaxonomy(catFilter, allTaxonomy);
      if (mainCat) {
        list = list.filter(t => {
          const tMain = getCategoryTaxonomy(t.category, allTaxonomy);
          return tMain?.id === mainCat.id || t.category === mainCat.name;
        });
      }
    }

    if (subFilter !== 'ALL') {
      list = list.filter(t => t.subCategory === subFilter);
    }

    return list;
  });

  public setCategoryFilter(id: string): void {
    this.activeCategoryFilter.set(id);
    this.activeSubCategoryFilter.set('ALL');
  }

  public setSubCategoryFilter(subName: string): void {
    this.activeSubCategoryFilter.set(subName);
  }

  public getTemplateCountForCategory(catId: string): number {
    if (catId === 'ALL') return this.templates().length;
    const allTaxonomy = this.taxonomy();
    const mainCat = getCategoryTaxonomy(catId, allTaxonomy);
    if (!mainCat) return 0;
    return this.templates().filter(t => {
      const tMain = getCategoryTaxonomy(t.category, allTaxonomy);
      return tMain?.id === mainCat.id || t.category === mainCat.name;
    }).length;
  }

  // ==========================================
  // GESTION DYNAMIQUE DES CATÉGORIES (MODAL)
  // ==========================================
  protected readonly isCategoryModalOpen = signal(false);
  protected readonly isCategoryFormOpen = signal(false);
  protected readonly isEditingCategory = signal(false);
  protected readonly editingCategoryId = signal<string | null>(null);

  protected catIdField = '';
  protected catNameField = '';
  protected catShortNameField = '';
  protected catIconField = 'fa-star';
  protected catColorAccentField = '#4f46e5';
  protected catSubCategoriesList: string[] = [];
  protected newSubCategoryInput = '';

  protected openCategoryModal(): void {
    this.isCategoryModalOpen.set(true);
    this.isCategoryFormOpen.set(false);
  }

  protected closeCategoryModal(): void {
    this.isCategoryModalOpen.set(false);
    this.isCategoryFormOpen.set(false);
  }

  protected openAddCategoryForm(): void {
    this.isEditingCategory.set(false);
    this.editingCategoryId.set(null);
    this.catIdField = '';
    this.catNameField = '';
    this.catShortNameField = '';
    this.catIconField = 'fa-star';
    this.catColorAccentField = '#4f46e5';
    this.catSubCategoriesList = [];
    this.newSubCategoryInput = '';
    this.isCategoryFormOpen.set(true);
  }

  protected openEditCategoryForm(cat: MainCategoryInfo): void {
    this.isEditingCategory.set(true);
    this.editingCategoryId.set(cat.id);
    this.catIdField = cat.id;
    this.catNameField = cat.name;
    this.catShortNameField = cat.shortName;
    this.catIconField = cat.icon || 'fa-star';
    this.catColorAccentField = cat.colorAccent || '#4f46e5';
    this.catSubCategoriesList = cat.subCategories ? cat.subCategories.map(s => s.name) : [];
    this.newSubCategoryInput = '';
    this.isCategoryFormOpen.set(true);
  }

  protected cancelCategoryForm(): void {
    this.isCategoryFormOpen.set(false);
  }

  protected addSubCategory(): void {
    const val = this.newSubCategoryInput?.trim();
    if (!val) return;
    if (!this.catSubCategoriesList.some(s => s.toLowerCase() === val.toLowerCase())) {
      this.catSubCategoriesList.push(val);
    }
    this.newSubCategoryInput = '';
  }

  protected removeSubCategory(index: number): void {
    if (index >= 0 && index < this.catSubCategoriesList.length) {
      this.catSubCategoriesList.splice(index, 1);
    }
  }

  protected onSubCategoryKeydown(event: KeyboardEvent): void {
    if (event.key === 'Enter') {
      event.preventDefault();
      this.addSubCategory();
    }
  }

  protected saveCategory(): void {
    if (!this.catNameField?.trim() || !this.catShortNameField?.trim()) {
      alert('Veuillez renseigner le nom complet et le nom court de la catégorie.');
      return;
    }

    // Auto-add any text typed in input if user didn't click + before submitting
    if (this.newSubCategoryInput?.trim()) {
      this.addSubCategory();
    }

    const subCatsList = this.catSubCategoriesList.filter(Boolean);

    const subCategories: SubCategoryInfo[] = subCatsList.map(name => ({
      name,
      icon: this.catIconField || 'fa-star',
      defaultSubtitle: `Célébration de ${name}`
    }));

    const catId = this.isEditingCategory() && this.editingCategoryId()
      ? this.editingCategoryId()!
      : (this.catIdField?.trim().toUpperCase().replace(/[^A-Z0-9_]/g, '_') || 
         this.catShortNameField.trim().toUpperCase().replace(/[^A-Z0-9_]/g, '_'));

    const categoryObj: MainCategoryInfo = {
      id: catId,
      name: this.catNameField.trim(),
      shortName: this.catShortNameField.trim(),
      icon: this.catIconField || 'fa-star',
      badgeClass: 'bg-primary-subtle text-primary border-primary-subtle',
      colorAccent: this.catColorAccentField || '#4f46e5',
      themeClass: `theme-${catId.toLowerCase()}`,
      subSummary: subCatsList.slice(0, 4).join(', ') || 'Modèles & Célébrations',
      subCategories
    };

    if (this.isEditingCategory() && this.editingCategoryId()) {
      this.templateService.updateCategory(this.editingCategoryId()!, categoryObj);
      this.successMessage.set(`Catégorie "${categoryObj.shortName}" modifiée avec succès.`);
    } else {
      this.templateService.addCategory(categoryObj);
      this.successMessage.set(`Catégorie "${categoryObj.shortName}" créée avec succès.`);
    }

    this.isCategoryFormOpen.set(false);
    setTimeout(() => this.successMessage.set(''), 4000);
  }

  protected deleteCategory(cat: MainCategoryInfo): void {
    if (confirm(`Êtes-vous sûr de vouloir supprimer la catégorie "${cat.shortName}" ?`)) {
      this.templateService.deleteCategory(cat.id);
      this.successMessage.set(`Catégorie "${cat.shortName}" supprimée.`);
      setTimeout(() => this.successMessage.set(''), 3000);
    }
  }

  protected isBuiltInDefaultCategory(id: string): boolean {
    return ['TRADITIONAL', 'FAMILY', 'CORPORATE', 'SEASONAL_SOCIAL', 'SCOLAIRE'].includes(id);
  }

  // Studio Page View & Form States
  protected readonly isEditorOpen = signal(false);
  protected readonly isModalOpen = computed(() => this.isEditorOpen());
  protected readonly isEditing = signal(false);
  protected readonly editingId = signal<number | null>(null);
  protected readonly isSubmitting = signal(false);
  protected readonly previewDevice = signal<'mobile' | 'desktop'>('mobile');
  protected readonly activeEditorTab = signal<'identity' | 'design' | 'media' | 'effects'>('identity');

  protected setEditorTab(tab: 'identity' | 'design' | 'media' | 'effects'): void {
    this.activeEditorTab.set(tab);
  }

  // Form Fields
  protected titleField = '';
  protected categoryField = 'Célébrations Traditionnelles & Culturelles';
  protected subCategoryField = 'Mariage';
  protected descriptionField = '';
  protected imageUrlField = '';
  protected backgroundImageUrlField = '';
  protected backgroundImageDesktopUrlField = '';
  protected musicUrlField = '';
  protected showMobileUrlInput = false;
  protected showDesktopUrlInput = false;
  protected showMusicUrlInput = false;

  protected getActiveMusicPreset(): { label: string; url: string } | undefined {
    return this.musicPresets.find(p => p.url === this.musicUrlField);
  }
  protected templateKeyField = '';
  protected decorativeFrameField = 'none';
  protected accentColorField = '#d4af37';
  protected backgroundColorField = '#faf6ee';
  protected primaryFontField = 'Alex Brush';
  protected primaryFontSizeField = '36px';
  protected primaryFontWeightField = '700';
  protected primaryLetterSpacingField = 'normal';
  protected secondaryFontField = 'Cinzel';
  protected secondaryFontSizeField = '16px';
  protected secondaryFontWeightField = '400';
  protected secondaryLetterSpacingField = 'normal';
  protected secondaryFontColorField = '#0f172a';
  protected htmlContentField = '';
  protected openingAnimationField = 'envelope-wax';
  protected visualParticlesField = 'gold-dust';
  protected backgroundMotionField = 'ken-burns';
  protected contentEntranceField = 'staggered-royal';
  protected showCountdownField = true;
  protected showCalendarButtonField = true;
  protected showMapRouteField = true;

  // Live Animation & Experience Preview States
  protected isPreviewOpened = signal<boolean>(false);
  protected isOpeningTransitioning = signal<boolean>(false);
  protected isAnimationReplaying = signal<boolean>(false);
  protected cardAnimationClass = signal<string>('animate__fadeIn');

  // Particle sets for live preview:
  // Mobile (<992px / mobile preview): Framed along lateral sides left <= 15% and right >= 85% to protect text.
  // Desktop (>=992px / desktop preview): Spread across the entire canvas (3% - 97%).
  protected readonly goldDustParticles = Array.from({ length: 22 }, (_, i) => {
    const isLeft = i % 2 === 0;
    const leftMobile = isLeft ? ((i * 7) % 13) + 2 : 85 + ((i * 7) % 13);
    const leftDesktop = ((i * 19 + 7) % 94) + 3;
    return {
      id: i,
      left: leftMobile + '%',
      leftDesktop: leftDesktop + '%',
      top: ((i * 23) % 88) + 6 + '%',
      size: ((i % 3) + 2.5) + 'px',
      delay: ((i * 0.45) % 5) + 's',
      duration: ((i % 3) * 2 + 8.5) + 's'
    };
  });

  protected readonly rosePetals = Array.from({ length: 16 }, (_, i) => {
    const isLeft = i % 2 === 0;
    const leftMobile = isLeft ? ((i * 8) % 14) + 2 : 84 + ((i * 8) % 14);
    const leftDesktop = ((i * 23 + 5) % 92) + 4;
    return {
      id: i,
      left: leftMobile + '%',
      leftDesktop: leftDesktop + '%',
      delay: ((i * 0.6) % 6) + 's',
      duration: ((i % 4) * 2.5 + 12) + 's',
      size: ((i % 4) * 1.5 + 7) + 'px',
      rotation: ((i * 47) % 360) + 'deg'
    };
  });

  protected readonly confettiPieces = Array.from({ length: 26 }, (_, i) => {
    const isLeft = i % 2 === 0;
    const leftMobile = isLeft ? ((i * 6) % 14) + 2 : 84 + ((i * 6) % 14);
    const leftDesktop = ((i * 17 + 9) % 94) + 3;
    return {
      id: i,
      left: leftMobile + '%',
      leftDesktop: leftDesktop + '%',
      delay: ((i * 0.4) % 5) + 's',
      duration: ((i % 3) * 2 + 9) + 's',
      color: ['#ffd700', '#f43f5e', '#3b82f6', '#10b981', '#a855f7', '#fbbf24'][i % 6],
      width: ((i % 2) === 0 ? 4 : 6) + 'px',
      height: ((i % 2) === 0 ? 6 : 4) + 'px'
    };
  });

  protected readonly sparklesStars = Array.from({ length: 16 }, (_, i) => {
    const isLeft = i % 2 === 0;
    const leftMobile = isLeft ? ((i * 7) % 14) + 2 : 84 + ((i * 7) % 14);
    const leftDesktop = ((i * 21 + 11) % 92) + 4;
    return {
      id: i,
      left: leftMobile + '%',
      leftDesktop: leftDesktop + '%',
      top: ((i * 19) % 85) + 8 + '%',
      delay: ((i * 0.5) % 4.5) + 's',
      duration: ((i % 3) * 1.5 + 5.5) + 's',
      size: ((i % 3) + 12) + 'px'
    };
  });

  protected readonly bokehBubbles = Array.from({ length: 8 }, (_, i) => {
    const isLeft = i % 2 === 0;
    const leftMobile = isLeft ? ((i * 6) % 12) + 1 : 87 + ((i * 6) % 12);
    const leftDesktop = ((i * 29 + 13) % 90) + 5;
    return {
      id: i,
      left: leftMobile + '%',
      leftDesktop: leftDesktop + '%',
      top: ((i * 31) % 75) + 10 + '%',
      size: (50 + (i % 4) * 20) + 'px',
      delay: (i * 0.6) + 's',
      duration: (6 + (i % 3) * 2) + 's'
    };
  });

  protected isEntranceActive(): boolean {
    const isInteractive = this.openingAnimationField === 'envelope-wax' || 
                          this.openingAnimationField === 'ribbon-cut' || 
                          this.openingAnimationField === 'curtain-unveil' || 
                          this.openingAnimationField === 'sliding-doors' ||
                          this.openingAnimationField === 'vip-badge';
    if (isInteractive) {
      return this.isOpeningTransitioning() || this.isPreviewOpened();
    }
    return this.isPreviewOpened();
  }

  protected openPreviewExperience(): void {
    if (this.isOpeningTransitioning() || this.isPreviewOpened()) return;
    this.isOpeningTransitioning.set(true);
    let duration = 800;
    if (this.openingAnimationField === 'envelope-wax') {
      duration = 1440;
    } else if (this.openingAnimationField === 'ribbon-cut') {
      duration = 1240;
    } else if (this.openingAnimationField === 'curtain-unveil') {
      duration = 1640;
    } else if (this.openingAnimationField === 'sliding-doors') {
      duration = 1540;
    } else if (this.openingAnimationField === 'vip-badge') {
      duration = 940;
    }
    setTimeout(() => {
      this.isPreviewOpened.set(true);
      this.isOpeningTransitioning.set(false);
    }, duration);
  }

  protected replayPreviewAnimation(): void {
    this.isAnimationReplaying.set(true);
    this.isOpeningTransitioning.set(false);
    this.isPreviewOpened.set(false);

    if (this.openingAnimationField === 'fade-in') {
      this.cardAnimationClass.set('animate__fadeIn');
      setTimeout(() => this.isPreviewOpened.set(true), 120);
    } else if (this.openingAnimationField === 'zoom-royal') {
      this.cardAnimationClass.set('animate__zoomIn');
      setTimeout(() => this.isPreviewOpened.set(true), 120);
    } else if (this.openingAnimationField === 'instant') {
      this.cardAnimationClass.set('');
      setTimeout(() => this.isPreviewOpened.set(true), 60);
    } else {
      this.cardAnimationClass.set('animate__fadeIn');
    }

    setTimeout(() => {
      this.isAnimationReplaying.set(false);
    }, 550);
  }

  protected onOpeningAnimationChange(): void {
    this.replayPreviewAnimation();
  }

  // ==========================================================================
  // TAB 4: VISUAL ANIMATIONS & EXPERIENCE OPTIONS
  // ==========================================================================
  protected readonly openingAnimationOptions = [
    { value: 'envelope-wax', label: 'Enveloppe Royale', sub: 'Sceau de cire & cachet 3D', icon: 'fa fa-envelope-open-text', emoji: '💌' },
    { value: 'curtain-unveil', label: 'Rideau de Gala', sub: 'Lever théâtral velours & or', icon: 'fa fa-masks-theater', emoji: '🎭' },
    { value: 'ribbon-cut', label: 'Ruban Inaugural', sub: 'Coupe laser & étincelles', icon: 'fa fa-ribbon', emoji: '✂️' },
    { value: 'sliding-doors', label: 'Portes Coulissantes', sub: 'Noyer noble & poignées or', icon: 'fa fa-door-open', emoji: '🏢' },
    { value: 'instant', label: 'Affichage Direct', sub: 'Sans couverture interactive', icon: 'fa fa-bolt', emoji: '⚡' }
  ];

  protected readonly visualParticlesOptions = [
    { value: 'gold-dust', label: 'Poussière Dorée', sub: 'Scintillements royaux', icon: 'fa fa-sparkles', emoji: '✨' },
    { value: 'rose-petals', label: 'Pétales de Rose', sub: 'Chute florale romantique', icon: 'fa fa-heart', emoji: '🌹' },
    { value: 'sparkles-stars', label: 'Étoiles & Éclats', sub: 'Féérie & magie lumineuse', icon: 'fa fa-star', emoji: '🌟' },
    { value: 'confetti', label: 'Confettis Festifs', sub: 'Ambiance de célébration', icon: 'fa fa-gift', emoji: '🎉' },
    { value: 'spotlight-glow', label: 'Balayage Lumineux', sub: 'Faisceau & éclat projecteur', icon: 'fa fa-lightbulb', emoji: '💡' },
    { value: 'none', label: 'Aucune Particule', sub: 'Fond épuré & minimaliste', icon: 'fa fa-ban', emoji: '🛑' }
  ];

  protected readonly backgroundMotionOptions = [
    { value: 'ken-burns', label: 'Zoom Ken Burns', sub: 'Zoom lent & panoramique doux', icon: 'fa fa-video', emoji: '🎥' },
    { value: 'floral-sway', label: 'Brise Florale', sub: 'Balancement doux & naturel', icon: 'fa fa-seedling', emoji: '🌿' },
    { value: 'shimmer-ray', label: 'Rayon Doré', sub: 'Reflet solaire périodique', icon: 'fa fa-sun', emoji: '✨' },
    { value: 'parallax-3d', label: 'Parallaxe 3D', sub: 'Profondeur dynamique immersive', icon: 'fa fa-cube', emoji: '📱' },
    { value: 'none', label: 'Arrière-plan Fixe', sub: 'Image statique classique', icon: 'fa fa-image', emoji: '🛑' }
  ];

  protected readonly contentEntranceOptions = [
    { value: 'staggered-royal', label: 'Cascade Royale (Zoom & Focus)', sub: 'Titre ➜ Message ➜ Détails', icon: 'fa fa-crown', emoji: '👑' },
    { value: 'lateral-slide', label: 'Glissement Latéral (Gauche & Droite)', sub: 'Croisement fluide et dynamique', icon: 'fa fa-arrows-left-right', emoji: '🌊' },
    { value: 'golden-glow-reveal', label: 'Éclat & Lueur Dorée', sub: 'Rayonnement lumineux étincelant', icon: 'fa fa-wand-magic-sparkles', emoji: '🌟' },
    { value: 'unfold-3d', label: 'Déroulement Papier 3D', sub: 'Ouverture perspective spatiale', icon: 'fa fa-scroll', emoji: '📜' },
    { value: 'direct', label: 'Affichage Immédiat', sub: 'Direct sans animation', icon: 'fa fa-bolt', emoji: '⚡' }
  ];

  protected selectOpeningAnimation(val: string): void {
    this.openingAnimationField = val;
    this.onOpeningAnimationChange();
  }

  protected selectVisualParticles(val: string): void {
    this.visualParticlesField = val;
  }

  protected selectBackgroundMotion(val: string): void {
    this.backgroundMotionField = val;
    this.replayPreviewAnimation();
  }

  protected selectContentEntrance(val: string): void {
    this.contentEntranceField = val;
    this.replayPreviewAnimation();
  }

  protected readonly availableSubCategoriesForForm = computed(() => {
    return getAllSubcategoriesForCategory(this.categoryField, this.taxonomy());
  });

  // Preset Font Sizes & Styles
  protected readonly primaryFontSizeOptions = ['28px', '32px', '36px', '40px', '48px', '56px'];
  protected readonly secondaryFontSizeOptions = ['13px', '14px', '16px', '18px', '20px', '22px'];
  
  protected readonly fontWeightOptions = [
    { label: 'Fin (300)', value: '300' },
    { label: 'Normal (400)', value: '400' },
    { label: 'Demi-Gras (600)', value: '600' },
    { label: 'Gras (700)', value: '700' },
    { label: 'Extra-Gras (800)', value: '800' }
  ];

  protected readonly letterSpacingOptions = [
    { label: 'Normal', value: 'normal' },
    { label: 'Discret (1px)', value: '1px' },
    { label: 'Aéré Prestige (2px)', value: '2px' },
    { label: 'Grand Format (3px)', value: '3px' },
    { label: 'Majestueux (4px)', value: '4px' }
  ];

  // Available Luxury Google Fonts with dynamic registration & priority sorting
  protected availableFonts: Array<{ name: string; label: string; fontGroup: string; sample: string }> = [
    { name: 'Alex Brush', label: 'Alex Brush (Script Délicat & Cérémonial)', fontGroup: 'Cursive', sample: 'Invitation Spéciale' },
    { name: 'Great Vibes', label: 'Great Vibes (Calligraphie Fluide & Romantique)', fontGroup: 'Cursive', sample: 'Yassine & Zineb' },
    { name: 'Dancing Script', label: 'Dancing Script (Moderne & Enjoué)', fontGroup: 'Cursive', sample: 'Soirée de Gala' },
    { name: 'Allura', label: 'Allura (Calligraphie Majestueuse)', fontGroup: 'Cursive', sample: 'Mariage Royal' },
    { name: 'Pinyon Script', label: 'Pinyon Script (Élégance Aristocratique)', fontGroup: 'Cursive', sample: 'Réception d\'Honneur' },
    { name: 'Parisienne', label: 'Parisienne (Romantisme Parisien)', fontGroup: 'Cursive', sample: 'Dîner aux Chandelles' },
    { name: 'Playfair Display', label: 'Playfair Display (Serif Luxueux & Éditorial)', fontGroup: 'Serif', sample: 'Mariage d\'Exception' },
    { name: 'Cormorant Garamond', label: 'Cormorant Garamond (Classique & Haute Joaillerie)', fontGroup: 'Serif', sample: 'Célébration Prestigieuse' },
    { name: 'Cinzel', label: 'Cinzel (Impérial & Monumental)', fontGroup: 'Serif', sample: 'RÉCEPTION ROYALE' },
    { name: 'Cinzel Decorative', label: 'Cinzel Decorative (Baroque Ornemental)', fontGroup: 'Serif', sample: 'GALA PRESTIGE' },
    { name: 'Prata', label: 'Prata (Serif Didone Raffiné)', fontGroup: 'Serif', sample: 'Cérémonie Privée' },
    { name: 'Bodoni Moda', label: 'Bodoni Moda (Haute Couture & Vogue)', fontGroup: 'Serif', sample: 'L\'Excellence' },
    { name: 'Montserrat', label: 'Montserrat (Moderne & Sans-Serif Épuré)', fontGroup: 'Sans-Serif', sample: 'Conférence & Événement' },
    { name: 'Plus Jakarta Sans', label: 'Plus Jakarta Sans (Contemporain & Lisible)', fontGroup: 'Sans-Serif', sample: 'Événement Corporate' }
  ];

  private fontDebounceTimeout: any = null;

  // Audio Preview & Presets
  protected readonly isPreviewAudioPlaying = signal(false);
  private previewAudioElement: HTMLAudioElement | null = null;
  protected readonly musicPresets = [
    { label: 'Mariage Marocain & Oud Calme', url: 'https://cdn.pixabay.com/download/audio/2022/11/06/audio_c3c3933c06.mp3' },
    { label: 'Romantique & Acoustique', url: 'https://cdn.pixabay.com/download/audio/2022/05/16/audio_db6591201e.mp3' },
    { label: 'Andalou Traditionnel', url: 'https://cdn.pixabay.com/download/audio/2022/01/18/audio_d0a13f69d2.mp3' },
    { label: 'Lounge & Jazz Élégant', url: 'https://cdn.pixabay.com/download/audio/2022/03/24/audio_33bd95d2c6.mp3' }
  ];

  /**
   * Enregistre une police saisie par l'utilisateur, la place tout en haut de la liste (1ère position)
   * et la sauvegarde dans le stockage local.
   */
  public registerAndPrioritizeFont(fontName?: string): void {
    if (!fontName) return;
    const clean = fontName.trim().replace(/['"]/g, '');
    if (clean.length < 2) return;

    loadGoogleFont(clean);

    const existingIndex = this.availableFonts.findIndex(
      f => f.name.toLowerCase() === clean.toLowerCase()
    );

    if (existingIndex > -1) {
      // Si déjà présente, la déplacer tout en haut
      const [item] = this.availableFonts.splice(existingIndex, 1);
      this.availableFonts.unshift(item);
    } else {
      // Nouvelle police : l'insérer au début de la liste
      this.availableFonts.unshift({
        name: clean,
        label: `${clean} (Personnalisée)`,
        fontGroup: 'Personnalisée',
        sample: clean
      });
    }

    this.saveCustomFontsToStorage();
  }

  private saveCustomFontsToStorage(): void {
    if (typeof localStorage === 'undefined') return;
    try {
      const customList = this.availableFonts
        .filter(f => f.fontGroup === 'Personnalisée')
        .map(f => f.name);
      localStorage.setItem('event_admin_custom_fonts', JSON.stringify(customList));
    } catch {
      // Ignore storage errors
    }
  }

  private loadCustomFontsFromStorage(): void {
    if (typeof localStorage === 'undefined') return;
    try {
      const stored = localStorage.getItem('event_admin_custom_fonts');
      if (stored) {
        const customNames: string[] = JSON.parse(stored);
        for (let i = customNames.length - 1; i >= 0; i--) {
          const name = customNames[i]?.trim();
          if (name && !this.availableFonts.some(f => f.name.toLowerCase() === name.toLowerCase())) {
            this.availableFonts.unshift({
              name,
              label: `${name} (Personnalisée)`,
              fontGroup: 'Personnalisée',
              sample: name
            });
            loadGoogleFont(name);
          }
        }
      }
    } catch {
      // Ignore storage errors
    }
  }

  public onPrimaryFontChange(val: string): void {
    this.primaryFontField = val;
    loadGoogleFont(val);
    if (this.fontDebounceTimeout) clearTimeout(this.fontDebounceTimeout);
    this.fontDebounceTimeout = setTimeout(() => {
      this.registerAndPrioritizeFont(val);
    }, 600);
  }

  public selectPrimaryFont(fontName: string): void {
    this.primaryFontField = fontName;
    this.registerAndPrioritizeFont(fontName);
  }

  public onSecondaryFontChange(val: string): void {
    this.secondaryFontField = val;
    loadGoogleFont(val);
    if (this.fontDebounceTimeout) clearTimeout(this.fontDebounceTimeout);
    this.fontDebounceTimeout = setTimeout(() => {
      this.registerAndPrioritizeFont(val);
    }, 600);
  }

  public selectSecondaryFont(fontName: string): void {
    this.secondaryFontField = fontName;
    this.registerAndPrioritizeFont(fontName);
  }

  public ngOnInit(): void {
    this.loadCustomFontsFromStorage();
    this.loadTemplates();
  }

  protected loadTemplates(): void {
    const cached = this.templateService.templates();
    if (cached.length > 0) {
      this.templates.set(cached);
      this.isLoading.set(false);
    } else {
      this.isLoading.set(true);
    }

    this.templateService.getTemplates().subscribe({
      next: (data) => {
        this.templates.set(data);
        this.isLoading.set(false);
      },
      error: (err) => {
        console.error(err);
        if (this.templates().length === 0) {
          this.errorMessage.set('Impossible de charger les modèles d\'invitation.');
        }
        this.isLoading.set(false);
      }
    });
  }

  public getMainCategoryBadgeClass(category: string): string {
    const tax = getCategoryTaxonomy(category, this.taxonomy());
    return tax ? tax.badgeClass : 'bg-secondary-subtle text-secondary';
  }

  public getMainCategoryIcon(category: string): string {
    const tax = getCategoryTaxonomy(category, this.taxonomy());
    return tax ? tax.icon : 'fa-tag';
  }

  public getSubCategoryIcon(category: string, subCategory?: string): string {
    if (!subCategory) return 'fa-folder';
    const tax = getCategoryTaxonomy(category, this.taxonomy());
    const sub = tax?.subCategories.find(s => s.name.toLowerCase() === subCategory.toLowerCase());
    return sub ? sub.icon : 'fa-star';
  }

  protected onBackgroundFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) {
      const file = input.files[0];
      const reader = new FileReader();
      reader.onload = (e) => {
        const rawResult = e.target?.result as string;
        if (!rawResult) return;

        const img = new Image();
        img.onload = () => {
          const maxDim = 1080;
          let width = img.width;
          let height = img.height;

          if (width > maxDim || height > maxDim) {
            if (width > height) {
              height = Math.round((height * maxDim) / width);
              width = maxDim;
            } else {
              width = Math.round((width * maxDim) / height);
              height = maxDim;
            }
          }

          const canvas = document.createElement('canvas');
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          if (ctx) {
            ctx.drawImage(img, 0, 0, width, height);
            this.backgroundImageUrlField = canvas.toDataURL('image/jpeg', 0.80);
          } else {
            this.backgroundImageUrlField = rawResult;
          }
          this.cdr.markForCheck();
        };
        img.src = rawResult;
      };
      reader.readAsDataURL(file);
    }
  }

  protected removeBackgroundImage(): void {
    this.backgroundImageUrlField = '';
    this.cdr.markForCheck();
  }

  protected onBackgroundDesktopFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) {
      const file = input.files[0];
      const reader = new FileReader();
      reader.onload = (e) => {
        const rawResult = e.target?.result as string;
        if (!rawResult) return;

        const img = new Image();
        img.onload = () => {
          const maxDim = 1440;
          let width = img.width;
          let height = img.height;

          if (width > maxDim || height > maxDim) {
            if (width > height) {
              height = Math.round((height * maxDim) / width);
              width = maxDim;
            } else {
              width = Math.round((width * maxDim) / height);
              height = maxDim;
            }
          }

          const canvas = document.createElement('canvas');
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          if (ctx) {
            ctx.drawImage(img, 0, 0, width, height);
            this.backgroundImageDesktopUrlField = canvas.toDataURL('image/jpeg', 0.80);
          } else {
            this.backgroundImageDesktopUrlField = rawResult;
          }
          this.cdr.markForCheck();
        };
        img.src = rawResult;
      };
      reader.readAsDataURL(file);
    }
  }

  protected removeBackgroundDesktopImage(): void {
    this.backgroundImageDesktopUrlField = '';
    this.cdr.markForCheck();
  }

  public getLivePreviewBackgroundImage(): string {
    if (this.previewDevice() === 'desktop') {
      return this.backgroundImageDesktopUrlField || this.backgroundImageUrlField || '';
    }
    return this.backgroundImageUrlField || '';
  }

  public getCardMobileBgColor(): string {
    if (this.isDarkBg(this.backgroundColorField)) {
      return 'rgba(10, 10, 15, 0.15)';
    }
    return 'rgba(255, 255, 255, 0.08)';
  }

  protected isBase64(val: string): boolean {
    return !!val && val.startsWith('data:');
  }

  protected onAudioFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) {
      const file = input.files[0];
      const reader = new FileReader();
      reader.onload = (e) => {
        const rawResult = e.target?.result as string;
        if (rawResult) {
          this.musicUrlField = rawResult;
          this.stopPreviewAudio();
          this.cdr.markForCheck();
        }
        input.value = '';
      };
      reader.readAsDataURL(file);
    }
  }

  protected removeMusic(): void {
    this.musicUrlField = '';
    this.stopPreviewAudio();
  }

  protected selectMusicPreset(url: string): void {
    if (this.musicUrlField === url) {
      this.togglePreviewAudio();
    } else {
      this.musicUrlField = url;
      this.stopPreviewAudio();
      this.togglePreviewAudio();
    }
  }

  protected togglePreviewAudio(): void {
    if (!this.musicUrlField?.trim()) return;

    if (this.isPreviewAudioPlaying()) {
      this.stopPreviewAudio();
    } else {
      if (!this.previewAudioElement) {
        this.previewAudioElement = new Audio();
        this.previewAudioElement.addEventListener('ended', () => {
          this.isPreviewAudioPlaying.set(false);
        });
        this.previewAudioElement.addEventListener('error', () => {
          this.isPreviewAudioPlaying.set(false);
        });
      }
      const targetSrc = this.musicUrlField.trim();
      if (this.previewAudioElement.src !== targetSrc) {
        this.previewAudioElement.src = targetSrc;
        this.previewAudioElement.load();
      }
      this.previewAudioElement.play()
        .then(() => this.isPreviewAudioPlaying.set(true))
        .catch(() => this.isPreviewAudioPlaying.set(false));
    }
  }

  protected stopPreviewAudio(): void {
    if (this.previewAudioElement) {
      try {
        this.previewAudioElement.pause();
        this.previewAudioElement.currentTime = 0;
      } catch (e) { }
    }
    this.isPreviewAudioPlaying.set(false);
  }

  public setPreviewDevice(device: 'mobile' | 'desktop'): void {
    this.previewDevice.set(device);
  }

  public isDarkBg(hexColor?: string): boolean {
    if (!hexColor) return false;
    let color = hexColor.trim();
    if (color.startsWith('#')) color = color.substring(1);
    if (color.length === 3) {
      color = color.split('').map(c => c + c).join('');
    }
    if (color.length !== 6) return false;
    const r = parseInt(color.substring(0, 2), 16);
    const g = parseInt(color.substring(2, 4), 16);
    const b = parseInt(color.substring(4, 6), 16);
    const yiq = ((r * 299) + (g * 587) + (b * 114)) / 1000;
    return yiq < 140;
  }

  protected openAddModal(): void {
    this.isEditing.set(false);
    this.editingId.set(null);
    this.titleField = '';
    this.categoryField = 'Célébrations Traditionnelles & Culturelles';
    this.subCategoryField = 'Mariage';
    this.descriptionField = '';
    this.imageUrlField = '';
    this.backgroundImageUrlField = '';
    this.backgroundImageDesktopUrlField = '';
    this.musicUrlField = '';
    this.templateKeyField = '';
    this.decorativeFrameField = 'none';
    this.accentColorField = '#d4af37';
    this.backgroundColorField = '#faf6ee';
    this.primaryFontField = 'Alex Brush';
    this.primaryFontSizeField = '36px';
    this.primaryFontWeightField = '700';
    this.primaryLetterSpacingField = 'normal';
    this.secondaryFontField = 'Cinzel';
    this.secondaryFontSizeField = '16px';
    this.secondaryFontWeightField = '400';
    this.secondaryLetterSpacingField = 'normal';
    this.secondaryFontColorField = '#0f172a';
    this.htmlContentField = '';
    this.openingAnimationField = 'envelope-wax';
    this.visualParticlesField = 'gold-dust';
    this.backgroundMotionField = 'ken-burns';
    this.contentEntranceField = 'staggered-royal';
    this.showCountdownField = true;
    this.showCalendarButtonField = true;
    this.showMapRouteField = true;
    this.errorMessage.set('');
    this.showMobileUrlInput = false;
    this.showDesktopUrlInput = false;
    this.showMusicUrlInput = false;
    this.activeEditorTab.set('identity');
    this.stopPreviewAudio();
    loadGoogleFont(this.primaryFontField);
    loadGoogleFont(this.secondaryFontField);
    this.isEditorOpen.set(true);
    this.replayPreviewAnimation();
  }

  protected openEditModal(template: DigitalTemplate): void {
    this.isEditing.set(true);
    this.editingId.set(template.id || null);
    this.activeEditorTab.set('identity');
    this.titleField = template.title || '';
    
    // Normalize category to full taxonomy title if needed
    const tax = getCategoryTaxonomy(template.category);
    this.categoryField = tax ? tax.name : (template.category || 'Célébrations Traditionnelles & Culturelles');
    this.subCategoryField = template.subCategory || (tax?.subCategories[0]?.name || 'Mariage');

    this.descriptionField = template.description || '';
    this.imageUrlField = template.imageUrl || '';
    this.backgroundImageUrlField = template.backgroundImageUrl || '';
    this.backgroundImageDesktopUrlField = template.backgroundImageDesktopUrl || '';
    this.musicUrlField = template.musicUrl || '';
    this.templateKeyField = template.templateKey || '';
    this.decorativeFrameField = template.decorativeFrame || 'none';
    this.accentColorField = template.accentColor || '#d4af37';
    this.backgroundColorField = template.backgroundColor || '#faf6ee';
    this.primaryFontField = template.primaryFont || 'Alex Brush';
    this.primaryFontSizeField = template.primaryFontSize || '36px';
    this.primaryFontWeightField = template.primaryFontWeight || '700';
    this.primaryLetterSpacingField = template.primaryLetterSpacing || 'normal';
    this.secondaryFontField = template.secondaryFont || 'Cinzel';
    this.secondaryFontSizeField = template.secondaryFontSize || '16px';
    this.secondaryFontWeightField = template.secondaryFontWeight || '400';
    this.secondaryLetterSpacingField = template.secondaryLetterSpacing || 'normal';
    this.secondaryFontColorField = template.secondaryFontColor || '#0f172a';
    this.htmlContentField = template.htmlContent || '';
    this.openingAnimationField = template.openingAnimation || 'envelope-wax';
    this.visualParticlesField = template.visualParticles || 'gold-dust';
    this.backgroundMotionField = template.backgroundMotion || 'ken-burns';
    this.contentEntranceField = template.contentEntrance || 'staggered-royal';
    this.showCountdownField = template.showCountdown !== false;
    this.showCalendarButtonField = template.showCalendarButton !== false;
    this.showMapRouteField = template.showMapRoute !== false;
    this.errorMessage.set('');
    this.showMobileUrlInput = false;
    this.showDesktopUrlInput = false;
    this.showMusicUrlInput = false;
    this.stopPreviewAudio();
    if (this.primaryFontField) {
      this.registerAndPrioritizeFont(this.primaryFontField);
    }
    if (this.secondaryFontField) {
      this.registerAndPrioritizeFont(this.secondaryFontField);
    }
    this.isEditorOpen.set(true);
    this.replayPreviewAnimation();
  }

  protected closeAddModal(): void {
    this.stopPreviewAudio();
    this.isEditorOpen.set(false);
  }

  protected onCategoryChange(): void {
    const subs = getAllSubcategoriesForCategory(this.categoryField);
    if (subs.length > 0) {
      this.subCategoryField = subs[0].name;
    }

    const tax = getCategoryTaxonomy(this.categoryField);
    if (tax?.id === 'TRADITIONAL') {
      this.decorativeFrameField = 'none';
      this.backgroundColorField = '#faf6ee';
      this.accentColorField = '#d4af37';
      this.primaryFontField = 'Alex Brush';
      this.primaryFontSizeField = '36px';
      this.primaryFontWeightField = '700';
      this.primaryLetterSpacingField = 'normal';
      this.secondaryFontField = 'Cinzel';
      this.secondaryFontSizeField = '16px';
      this.secondaryFontWeightField = '400';
      this.secondaryLetterSpacingField = 'normal';
      this.secondaryFontColorField = '#0f172a';
      this.openingAnimationField = 'envelope-wax';
      this.visualParticlesField = 'gold-dust';
    } else if (tax?.id === 'FAMILY') {
      this.decorativeFrameField = 'none';
      this.backgroundColorField = '#fff9f5';
      this.accentColorField = '#c27ba0';
      this.primaryFontField = 'Great Vibes';
      this.primaryFontSizeField = '38px';
      this.primaryFontWeightField = '700';
      this.primaryLetterSpacingField = 'normal';
      this.secondaryFontField = 'Cormorant Garamond';
      this.secondaryFontSizeField = '16px';
      this.secondaryFontWeightField = '400';
      this.secondaryLetterSpacingField = 'normal';
      this.secondaryFontColorField = '#2c1810';
      this.openingAnimationField = 'envelope-wax';
      this.visualParticlesField = 'rose-petals';
    } else if (tax?.id === 'CORPORATE') {
      this.decorativeFrameField = 'none';
      this.backgroundColorField = '#f8f9fa';
      this.accentColorField = '#2b4c7e';
      this.primaryFontField = 'Montserrat';
      this.primaryFontSizeField = '32px';
      this.primaryFontWeightField = '600';
      this.primaryLetterSpacingField = '1px';
      this.secondaryFontField = 'Playfair Display';
      this.secondaryFontSizeField = '15px';
      this.secondaryFontWeightField = '400';
      this.secondaryLetterSpacingField = 'normal';
      this.secondaryFontColorField = '#1e293b';
      this.openingAnimationField = 'vip-badge';
      this.visualParticlesField = 'gold-dust';
    } else if (tax?.id === 'SEASONAL_SOCIAL') {
      this.decorativeFrameField = 'none';
      this.backgroundColorField = '#0b0b0b';
      this.accentColorField = '#fbbf24';
      this.primaryFontField = 'Playfair Display';
      this.primaryFontSizeField = '36px';
      this.primaryFontWeightField = '700';
      this.primaryLetterSpacingField = '2px';
      this.secondaryFontField = 'Cinzel';
      this.secondaryFontSizeField = '16px';
      this.secondaryFontWeightField = '400';
      this.secondaryLetterSpacingField = '1px';
      this.secondaryFontColorField = '#f0dd9e';
      this.openingAnimationField = 'ribbon-cut';
      this.visualParticlesField = 'sparkles-stars';
    }
    this.replayPreviewAnimation();
  }

  private async compressBase64Image(dataUrl: string, maxDim: number = 850, quality: number = 0.75): Promise<string> {
    if (!dataUrl || !dataUrl.startsWith('data:image') || dataUrl.length < 100000) {
      return dataUrl;
    }
    return new Promise<string>((resolve) => {
      const img = new Image();
      img.onload = () => {
        let width = img.width;
        let height = img.height;
        if (width > maxDim || height > maxDim) {
          if (width > height) {
            height = Math.round((height * maxDim) / width);
            width = maxDim;
          } else {
            width = Math.round((width * maxDim) / height);
            height = maxDim;
          }
        }
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          resolve(canvas.toDataURL('image/jpeg', quality));
        } else {
          resolve(dataUrl);
        }
      };
      img.onerror = () => resolve(dataUrl);
      img.src = dataUrl;
    });
  }

  protected async saveTemplate(): Promise<void> {
    if (!this.titleField.trim()) {
      this.errorMessage.set('Le nom du modèle est obligatoire.');
      return;
    }

    this.isSubmitting.set(true);
    this.errorMessage.set('');

    // Automatically optimize & compress any heavy base64 images before network transmission
    let compressedMobile = this.backgroundImageUrlField?.trim() || null;
    let compressedDesktop = this.backgroundImageDesktopUrlField?.trim() || null;

    if (compressedMobile && compressedMobile.startsWith('data:image')) {
      compressedMobile = await this.compressBase64Image(compressedMobile, 850, 0.75);
    }
    if (compressedDesktop && compressedDesktop.startsWith('data:image')) {
      compressedDesktop = await this.compressBase64Image(compressedDesktop, 1200, 0.75);
    }

    const templatePayload: DigitalTemplate = {
      title: this.titleField.trim(),
      category: this.categoryField,
      subCategory: this.subCategoryField,
      description: this.descriptionField?.trim() || '',
      imageUrl: this.imageUrlField?.trim() || undefined,
      backgroundImageUrl: compressedMobile,
      backgroundImageDesktopUrl: compressedDesktop,
      musicUrl: this.musicUrlField?.trim() ? this.musicUrlField.trim() : null,
      templateKey: this.templateKeyField?.trim() || undefined,
      decorativeFrame: this.decorativeFrameField || 'none',
      accentColor: this.accentColorField?.trim() || '#d4af37',
      backgroundColor: this.backgroundColorField?.trim() || '#faf6ee',
      primaryFont: this.primaryFontField?.trim() || 'Alex Brush',
      primaryFontSize: this.primaryFontSizeField?.trim() || '36px',
      primaryFontWeight: this.primaryFontWeightField || '700',
      primaryLetterSpacing: this.primaryLetterSpacingField || 'normal',
      secondaryFont: this.secondaryFontField?.trim() || 'Cinzel',
      secondaryFontSize: this.secondaryFontSizeField?.trim() || '16px',
      secondaryFontWeight: this.secondaryFontWeightField || '400',
      secondaryLetterSpacing: this.secondaryLetterSpacingField || 'normal',
      secondaryFontColor: this.secondaryFontColorField?.trim() || '#0f172a',
      htmlContent: this.htmlContentField?.trim() || undefined,
      openingAnimation: this.openingAnimationField || 'envelope-wax',
      visualParticles: this.visualParticlesField || 'none',
      backgroundMotion: this.backgroundMotionField || 'none',
      contentEntrance: this.contentEntranceField || 'staggered-royal',
      showCountdown: this.showCountdownField,
      showCalendarButton: this.showCalendarButtonField,
      showMapRoute: this.showMapRouteField
    };

    if (this.isEditing() && this.editingId()) {
      this.templateService.updateTemplate(this.editingId()!, templatePayload).subscribe({
        next: (updated) => {
          this.templates.update(list => list.map(t => t.id === updated.id ? { ...t, ...updated } : t));
          this.successMessage.set('Modèle d\'invitation mis à jour avec succès.');
          this.closeAddModal();
          this.isSubmitting.set(false);
          setTimeout(() => this.successMessage.set(''), 3500);
        },
        error: (err) => {
          console.error(err);
          this.errorMessage.set('Une erreur est survenue lors de la mise à jour.');
          this.isSubmitting.set(false);
        }
      });
    } else {
      this.templateService.createTemplate(templatePayload).subscribe({
        next: (created) => {
          this.templates.update(list => [...list, created]);
          this.successMessage.set('Nouveau modèle d\'invitation créé avec succès.');
          this.closeAddModal();
          this.isSubmitting.set(false);
          setTimeout(() => this.successMessage.set(''), 3500);
        },
        error: (err) => {
          console.error(err);
          this.errorMessage.set('Une erreur est survenue lors de la création.');
          this.isSubmitting.set(false);
        }
      });
    }
  }

  protected deleteTemplate(id: number): void {
    if (confirm('Êtes-vous sûr de vouloir supprimer définitivement ce modèle d\'invitation ?')) {
      this.templateService.deleteTemplate(id).subscribe({
        next: () => {
          this.templates.update(list => list.filter(t => t.id !== id));
          this.successMessage.set('Modèle supprimé avec succès.');
          setTimeout(() => this.successMessage.set(''), 3000);
        },
        error: (err) => {
          console.error(err);
          this.errorMessage.set('Une erreur est survenue lors de la suppression.');
        }
      });
    }
  }

  protected isDarkTheme(): boolean {
    if (this.secondaryFontColorField && !this.isDarkBg(this.secondaryFontColorField)) {
      return true;
    }
    if (this.backgroundColorField && this.isDarkBg(this.backgroundColorField)) {
      return true;
    }
    if (this.backgroundImageUrlField) {
      return true;
    }
    return false;
  }

  protected getMusicWidgetBtnBg(): string {
    if (this.isDarkTheme()) {
      return this.isPreviewAudioPlaying()
        ? (this.accentColorField ? (this.accentColorField + '38') : 'rgba(212, 175, 55, 0.35)')
        : 'rgba(255, 255, 255, 0.12)';
    }
    return this.isPreviewAudioPlaying()
      ? 'rgba(255, 255, 255, 0.98)'
      : '#ffffff';
  }

  protected getMusicWidgetBtnColor(): string {
    return this.accentColorField || '#d4af37';
  }

  protected getMusicWidgetBtnBorder(): string {
    return this.accentColorField
      ? (this.accentColorField + '90')
      : 'rgba(212, 175, 55, 0.6)';
  }

  protected getMusicWidgetLabelBg(): string {
    if (this.isDarkTheme()) {
      return 'rgba(255, 255, 255, 0.12)';
    }
    return '#ffffff';
  }

  protected getMusicWidgetLabelTextColor(): string {
    if (this.isDarkTheme()) {
      return this.secondaryFontColorField || '#ffffff';
    }
    return '#1e293b';
  }

  protected getMusicWidgetLabelBorder(): string {
    return this.accentColorField
      ? (this.accentColorField + '75')
      : 'rgba(212, 175, 55, 0.45)';
  }
}
