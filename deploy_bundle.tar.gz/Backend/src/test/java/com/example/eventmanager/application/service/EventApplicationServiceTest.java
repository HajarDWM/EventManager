package com.example.eventmanager.application.service;

import com.example.eventmanager.application.dto.EventDTO;
import com.example.eventmanager.application.mapper.EventMapper;
import com.example.eventmanager.application.port.out.EventRepositoryPort;
import com.example.eventmanager.application.port.out.SecurityContextPort;
import com.example.eventmanager.domain.exception.EventNotFoundException;
import com.example.eventmanager.domain.exception.UnauthorizedAccessException;
import com.example.eventmanager.domain.model.Event;
import com.example.eventmanager.domain.model.EventStatus;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import com.example.eventmanager.application.port.out.CatererRepositoryPort;

@ExtendWith(MockitoExtension.class)
class EventApplicationServiceTest {

    @Mock
    private EventRepositoryPort eventRepositoryPort;

    @Mock
    private EventMapper eventMapper;

    @Mock
    private SecurityContextPort securityContextPort;

    @Mock
    private CatererRepositoryPort catererRepositoryPort;

    @InjectMocks
    private EventApplicationService eventApplicationService;

    private EventDTO eventDTO;
    private Event event;

    @BeforeEach
    void setUp() {
        eventDTO = EventDTO.builder()
                .title("Mariage test")
                .eventDate(LocalDateTime.now())
                .location("Paris")
                .guestCount(100)
                .catererId(1L)
                .build();

        event = Event.builder()
                .id(1L)
                .title("Mariage test")
                .eventDate(LocalDateTime.now())
                .location("Paris")
                .guestCount(100)
                .catererId(1L)
                .status(EventStatus.DRAFT)
                .build();
    }

    @Test
    void createEvent_ShouldSetStatusToDraft_WhenStatusIsNull() {
        // Arrange
        when(securityContextPort.getCurrentCatererId()).thenReturn(1L);
        com.example.eventmanager.domain.model.Caterer caterer = com.example.eventmanager.domain.model.Caterer.builder()
                .id(1L)
                .role(com.example.eventmanager.domain.model.CatererRole.TRAITEUR)
                .subscriptionPlan("FREE")
                .build();
        when(catererRepositoryPort.findById(1L)).thenReturn(Optional.of(caterer));
        when(eventRepositoryPort.findAllByCatererId(1L)).thenReturn(java.util.Collections.emptyList());
        when(eventMapper.toDomain(eventDTO)).thenReturn(event);
        when(eventRepositoryPort.save(any(Event.class))).thenReturn(event);
        
        EventDTO returnedDTO = EventDTO.builder().id(1L).status("DRAFT").build();
        when(eventMapper.toDTO(event)).thenReturn(returnedDTO);

        // Act
        EventDTO result = eventApplicationService.createEvent(eventDTO);

        // Assert
        assertNotNull(result);
        assertEquals("DRAFT", result.getStatus());
        verify(eventRepositoryPort, times(1)).save(event);
        assertEquals(EventStatus.DRAFT, event.getStatus());
        assertEquals(1L, event.getCatererId());
    }

    @Test
    void createEvent_ShouldThrowException_WhenQuotaExceeded() {
        // Arrange
        when(securityContextPort.getCurrentCatererId()).thenReturn(1L);
        com.example.eventmanager.domain.model.Caterer caterer = com.example.eventmanager.domain.model.Caterer.builder()
                .id(1L)
                .role(com.example.eventmanager.domain.model.CatererRole.TRAITEUR)
                .subscriptionPlan("FREE") // limit is 2
                .build();
        when(catererRepositoryPort.findById(1L)).thenReturn(Optional.of(caterer));
        
        // Mock existing events returning 2 events
        java.util.List<Event> mockEvents = java.util.List.of(mock(Event.class), mock(Event.class));
        when(eventRepositoryPort.findAllByCatererId(1L)).thenReturn(mockEvents);
        when(eventRepositoryPort.countByCatererId(1L)).thenReturn(2L);

        // Act & Assert
        com.example.eventmanager.domain.exception.SubscriptionRequiredException exception = assertThrows(com.example.eventmanager.domain.exception.SubscriptionRequiredException.class, () -> {
            eventApplicationService.createEvent(eventDTO);
        });
        assertEquals("You have reached your free event limit. Please upgrade your plan to create more events.", exception.getMessage());
        verify(eventRepositoryPort, never()).save(any(Event.class));
    }

    @Test
    void createEvent_ShouldThrowException_WhenStandardPlanGuestLimitExceeded() {
        // Arrange
        when(securityContextPort.getCurrentCatererId()).thenReturn(1L);
        com.example.eventmanager.domain.model.Caterer caterer = com.example.eventmanager.domain.model.Caterer.builder()
                .id(1L)
                .role(com.example.eventmanager.domain.model.CatererRole.TRAITEUR)
                .subscriptionPlan("STANDARD") // Standard Pro Plan
                .build();
        when(catererRepositoryPort.findById(1L)).thenReturn(Optional.of(caterer));
        when(eventRepositoryPort.findAllByCatererId(1L)).thenReturn(java.util.List.of());

        // Event exceeding guest limit (301 guests)
        EventDTO invalidEvent = new EventDTO();
        invalidEvent.setTitle("Mariage VIP");
        invalidEvent.setGuestCount(301);

        // Act & Assert
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            eventApplicationService.createEvent(invalidEvent);
        });
        assertEquals("Le forfait limite le nombre d'invités à 300 par événement. Veuillez passer au forfait Premium VIP pour inviter plus de personnes.", exception.getMessage());
        verify(eventRepositoryPort, never()).save(any(Event.class));
    }

    @Test
    void createEvent_ShouldThrowException_WhenFreePlanGuestLimitExceeded() {
        // Arrange
        when(securityContextPort.getCurrentCatererId()).thenReturn(1L);
        com.example.eventmanager.domain.model.Caterer caterer = com.example.eventmanager.domain.model.Caterer.builder()
                .id(1L)
                .role(com.example.eventmanager.domain.model.CatererRole.TRAITEUR)
                .subscriptionPlan("FREE") // Free Plan
                .build();
        when(catererRepositoryPort.findById(1L)).thenReturn(Optional.of(caterer));
        when(eventRepositoryPort.findAllByCatererId(1L)).thenReturn(java.util.List.of());

        // Event exceeding guest limit (301 guests)
        EventDTO invalidEvent = new EventDTO();
        invalidEvent.setTitle("Petit Mariage");
        invalidEvent.setGuestCount(301);

        // Act & Assert
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            eventApplicationService.createEvent(invalidEvent);
        });
        assertEquals("Le forfait limite le nombre d'invités à 300 par événement. Veuillez passer au forfait Premium VIP pour inviter plus de personnes.", exception.getMessage());
        verify(eventRepositoryPort, never()).save(any(Event.class));
    }

    @Test
    void getEventById_ShouldReturnEvent_WhenEventExistsAndBelongsToCaterer() {
        // Arrange
        when(securityContextPort.getCurrentCatererId()).thenReturn(1L);
        when(eventRepositoryPort.findById(1L)).thenReturn(Optional.of(event));
        when(eventMapper.toDTO(event)).thenReturn(eventDTO);

        // Act
        EventDTO result = eventApplicationService.getEventById(1L);

        // Assert
        assertNotNull(result);
        assertEquals("Mariage test", result.getTitle());
        verify(eventRepositoryPort, times(1)).findById(1L);
    }

    @Test
    void getEventById_ShouldThrowUnauthorized_WhenEventBelongsToAnotherCaterer() {
        // Arrange
        when(securityContextPort.getCurrentCatererId()).thenReturn(2L); // Different caterer
        when(eventRepositoryPort.findById(1L)).thenReturn(Optional.of(event)); // Event belongs to caterer 1

        // Act & Assert
        assertThrows(UnauthorizedAccessException.class, () -> eventApplicationService.getEventById(1L));
        verify(eventRepositoryPort, times(1)).findById(1L);
        verify(eventMapper, never()).toDTO(any());
    }

    @Test
    void getEventById_ShouldThrowException_WhenEventDoesNotExist() {
        // Arrange
        when(securityContextPort.getCurrentCatererId()).thenReturn(1L);
        when(eventRepositoryPort.findById(99L)).thenReturn(Optional.empty());

        // Act & Assert
        assertThrows(EventNotFoundException.class, () -> eventApplicationService.getEventById(99L));
        verify(eventRepositoryPort, times(1)).findById(99L);
    }
}
