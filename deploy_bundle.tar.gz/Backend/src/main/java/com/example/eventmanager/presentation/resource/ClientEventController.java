package com.example.eventmanager.presentation.resource;

import com.example.eventmanager.application.dto.EventDTO;
import com.example.eventmanager.application.mapper.EventMapper;
import com.example.eventmanager.infrastructure.persistence.entity.EventEntity;
import com.example.eventmanager.infrastructure.persistence.mapper.EventPersistenceMapper;
import com.example.eventmanager.infrastructure.persistence.repository.EventRepository;
import com.example.eventmanager.infrastructure.security.model.ClientUserDetails;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.eventmanager.infrastructure.persistence.repository.QuoteRepository;
import com.example.eventmanager.infrastructure.persistence.repository.InvoiceRepository;
import com.example.eventmanager.infrastructure.persistence.entity.QuoteEntity;
import com.example.eventmanager.infrastructure.persistence.entity.InvoiceEntity;
import com.example.eventmanager.infrastructure.persistence.entity.PaymentEntity;
import com.example.eventmanager.infrastructure.persistence.repository.DigitalInvitationTemplateRepository;
import com.example.eventmanager.infrastructure.persistence.entity.DigitalInvitationTemplateEntity;
import com.example.eventmanager.infrastructure.persistence.repository.CatererRepository;
import com.example.eventmanager.infrastructure.persistence.repository.ClientRepository;
import java.math.BigDecimal;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v1/client/events")
@RequiredArgsConstructor
public class ClientEventController {

    private final EventRepository eventRepository;
    private final EventPersistenceMapper eventPersistenceMapper;
    private final EventMapper eventMapper;
    private final QuoteRepository quoteRepository;
    private final InvoiceRepository invoiceRepository;
    private final DigitalInvitationTemplateRepository templateRepository;
    private final CatererRepository catererRepository;
    private final ClientRepository clientRepository;

    @GetMapping
    @Transactional(readOnly = true)
    public ResponseEntity<List<EventDTO>> getClientEvents(@AuthenticationPrincipal ClientUserDetails clientDetails) {
        if (clientDetails == null) {
            return ResponseEntity.status(401).build();
        }

        List<EventEntity> events = eventRepository.findByClientId(clientDetails.getClientId());
        List<EventDTO> eventDTOs = events.stream()
                .map(eventPersistenceMapper::toDomain)
                .map(event -> {
                    EventDTO dto = eventMapper.toDTO(event);
                    
                    // Dynamic Calculation Alignment
                    List<QuoteEntity> quotes = quoteRepository.findByEventId(event.getId());
                    QuoteEntity globalQuote = quotes.stream()
                        .filter(q -> (q.getReference() != null && q.getReference().startsWith("QT-GLOBAL-")) 
                                || "ACCEPTED".equals(q.getStatus()) || "INVOICED".equals(q.getStatus()))
                        .findFirst()
                        .orElse(quotes.isEmpty() ? null : quotes.get(0));

                    double totalContract = 0.0;
                    if (globalQuote != null && globalQuote.getTotalTtc() != null) {
                        totalContract = globalQuote.getTotalTtc().doubleValue();
                    }

                    List<InvoiceEntity> invoices = invoiceRepository.findByEventId(event.getId());
                    InvoiceEntity globalInvoice = invoices.isEmpty() ? null : invoices.get(0);

                    double depositsPaid = 0.0;
                    if (globalInvoice != null && globalInvoice.getPayments() != null) {
                        depositsPaid = globalInvoice.getPayments().stream()
                            .map(PaymentEntity::getAmount)
                            .filter(java.util.Objects::nonNull)
                            .mapToDouble(BigDecimal::doubleValue)
                            .sum();
                    }

                    double balanceDue = totalContract - depositsPaid;
                    if (balanceDue < 0) balanceDue = 0.0;

                    dto.setTotalContractAmount(totalContract);
                    dto.setDepositsPaid(depositsPaid);
                    dto.setBalanceDue(balanceDue);

                    java.util.Optional<com.example.eventmanager.infrastructure.persistence.entity.DigitalInvitationTemplateEntity> tplOpt = java.util.Optional.empty();
                    if (event.getDigitalTemplateId() != null) {
                        tplOpt = templateRepository.findById(event.getDigitalTemplateId());
                    }
                    if (tplOpt.isEmpty() && event.getTemplateId() != null && !event.getTemplateId().isBlank()) {
                        try {
                            Long tId = Long.parseLong(event.getTemplateId());
                            tplOpt = templateRepository.findById(tId);
                        } catch (NumberFormatException ignored) {}
                        if (tplOpt.isEmpty()) {
                            tplOpt = templateRepository.findByTemplateKeyIgnoreCase(event.getTemplateId());
                        }
                    }
                    tplOpt.ifPresent(template -> {
                        dto.setTemplateBackgroundImageUrl(template.getBackgroundImageUrl());
                        dto.setTemplateBackgroundImageDesktopUrl(template.getBackgroundImageDesktopUrl());
                        dto.setTemplateId(template.getTemplateKey());
                        dto.setDigitalTemplateId(template.getId());
                    });

                    if (event.getCatererId() != null) {
                        catererRepository.findById(event.getCatererId())
                                .ifPresent(caterer -> {
                                    dto.setCatererName(caterer.getBusinessName());
                                    dto.setCatererEmail(caterer.getEmail());
                                });
                    }
                    
                    if (event.getClientId() != null) {
                        clientRepository.findById(event.getClientId())
                                .ifPresent(c -> {
                                    dto.setClientName(c.getName());
                                    dto.setClientEmail(c.getEmail());
                                    dto.setClientPhone(c.getPhone());
                                });
                    }
                    
                    return dto;
                })
                .collect(Collectors.toList());

        return ResponseEntity.ok(eventDTOs);
    }
}
