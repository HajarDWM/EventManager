package com.example.eventmanager.infrastructure.persistence.mapper;

import com.example.eventmanager.domain.model.Event;
import com.example.eventmanager.domain.model.EventStatus;
import com.example.eventmanager.infrastructure.persistence.entity.EventEntity;
import org.springframework.stereotype.Component;

@Component
public class EventPersistenceMapper {

    public Event toDomain(EventEntity entity) {
        if (entity == null) {
            return null;
        }

        return Event.builder()
                .id(entity.getId())
                .title(entity.getTitle())
                .eventDate(entity.getEventDate())
                .location(entity.getLocation())
                .locationMapUrl(entity.getLocationMapUrl())
                .guestCount(entity.getGuestCount())
                .status(entity.getStatus() != null ? EventStatus.valueOf(entity.getStatus()) : EventStatus.DRAFT)
                .catererId(entity.getCatererId())
                .clientId(entity.getClientId())
                .archived(entity.isArchived())
                .createdAt(entity.getCreatedAt())
                .digitalTemplateId(entity.getDigitalTemplateId())
                .invitationToken(entity.getInvitationToken())
                .invitationTitle(entity.getInvitationTitle())
                .invitationSubtitle(entity.getInvitationSubtitle())
                .invitationDate(entity.getInvitationDate())
                .invitationLocation(entity.getInvitationLocation())
                .parkingLocation(entity.getParkingLocation())
                .mealType(entity.getMealType())
                .templateId(entity.getTemplateId())
                .isPaidEvent(entity.isPaidEvent())
                .ticketPrice(entity.getTicketPrice())
                .currency(entity.getCurrency())
                .tableShape(entity.getTableShape() != null ? entity.getTableShape() : "ROUND")
                .tableCapacity(entity.getTableCapacity() != null ? entity.getTableCapacity() : 10)
                .tablesCount(entity.getTablesCount())
                .build();
    }

    public EventEntity toEntity(Event domain) {
        if (domain == null) {
            return null;
        }

        return EventEntity.builder()
                .id(domain.getId())
                .title(domain.getTitle())
                .eventDate(domain.getEventDate())
                .location(domain.getLocation())
                .locationMapUrl(domain.getLocationMapUrl())
                .guestCount(domain.getGuestCount())
                .status(domain.getStatus() != null ? domain.getStatus().name() : "DRAFT")
                .catererId(domain.getCatererId())
                .clientId(domain.getClientId())
                .archived(domain.isArchived())
                .createdAt(domain.getCreatedAt())
                .digitalTemplateId(domain.getDigitalTemplateId())
                .templateId(domain.getTemplateId())
                .invitationToken(domain.getInvitationToken())
                .invitationTitle(domain.getInvitationTitle())
                .invitationSubtitle(domain.getInvitationSubtitle())
                .invitationDate(domain.getInvitationDate())
                .invitationLocation(domain.getInvitationLocation())
                .parkingLocation(domain.getParkingLocation())
                .mealType(domain.getMealType())
                .isPaidEvent(domain.isPaidEvent())
                .ticketPrice(domain.getTicketPrice())
                .currency(domain.getCurrency())
                .tableShape(domain.getTableShape() != null ? domain.getTableShape() : "ROUND")
                .tableCapacity(domain.getTableCapacity() != null ? domain.getTableCapacity() : 10)
                .tablesCount(domain.getTablesCount())
                .build();
    }
}
