package com.example.eventmanager.application.port.in;

import com.example.eventmanager.application.dto.CatererDTO;

import java.util.List;

public interface AdminCatererUseCase {
    List<CatererDTO> getAllCaterers(String status);
    CatererDTO updateCatererStatusAndSubscription(Long id, String accountStatus, String plan, String subscriptionStatus, java.time.LocalDateTime startDate, java.time.LocalDateTime endDate);
    CatererDTO createCaterer(CatererDTO dto);
}
